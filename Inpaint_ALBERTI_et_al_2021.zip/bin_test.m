



phi_bin=linspace(1,60,60);




vol_bin=logspace(1,8,20);

jj=1;
for k=2:length(vol_bin)
   idx=find(out_vol>=vol_bin(k-1) & out_vol<vol_bin(k) & out_phi_max>0);
   mean_phi(jj,1)=median(out_phi_max(idx));
   
   for kk=1:length(idx)
      c_eq(kk,1)=interp1(out_phi_test(:,idx(kk))',out_cf(:,idx(kk))',mean_phi(jj,1));
       
   end
   
   mean_c(jj,1)=mean(out_c_max(idx),'omitnan');
%    mean_c(jj,1)=mean(c_eq,'omitnan');
   %mean_c=mean(out_phi_max(idx));
   mean_thick(jj,1)=vol_bin(jj)./((vol_bin(jj)./0.074).^(1/1.45));
   jj=jj+1; 
    
end

figure;
subplot(1,3,1)
plot(mean_c)
subplot(1,3,2)
plot(mean_thick)
subplot(1,3,3)
plot(mean_c./mean_thick)

