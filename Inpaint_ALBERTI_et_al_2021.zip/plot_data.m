close all

load('C:\Users\albertis\Desktop\Inpaint_nans\Results\Brookings\output_sat_0_brookings.mat');
phi=brookings.phi_max;
coh=brookings.c_max;
rel=brookings.Relief;
thick=brookings.MeanThickness;
VA=brookings.VolumeAreaRatio;
vol=brookings.Volume;
area=brookings.Area;

load('C:\Users\albertis\Desktop\Inpaint_nans\Results\Elk\output_sat_0_elk.mat');
phi=vertcat(phi,elk.phi_max);
coh=vertcat(coh,elk.c_max);
rel=vertcat(rel,elk.Relief);
thick=vertcat(thick,elk.MeanThickness);
VA=vertcat(VA,elk.VolumeAreaRatio);
vol=vertcat(vol,elk.Volume);
area=vertcat(area,elk.Area);

load('C:\Users\albertis\Desktop\Inpaint_nans\Results\Gales\output_sat_0_gales.mat');
phi=vertcat(phi,gales.phi_max);
coh=vertcat(coh,gales.c_max);
rel=vertcat(rel,gales.Relief);
thick=vertcat(thick,gales.MeanThickness);
VA=vertcat(VA,gales.VolumeAreaRatio);
vol=vertcat(vol,gales.Volume);
area=vertcat(area,gales.Area);

cnorm=coh./(thick.*20);

vol(cnorm==0)=NaN;
area(cnorm==0)=NaN;

figure(1)
scatter(area,cnorm,'b','filled');
hold on
grid on
%set(gca,'Yscale','log');
set(gca,'Xscale','log');

[vsort,idx]=sort(area);
cnorm=cnorm(idx);
window=500;
meanc=movmean(cnorm,window,'Endpoints','shrink');
stdc=movstd(cnorm,window,'Endpoints','shrink');
medianc=movmedian(cnorm,window,'Endpoints','shrink');

plot(vsort,medianc,'r','LineWidth',3)
plot(vsort,meanc,'k','LineWidth',3)
plot(vsort,meanc+stdc,'k:','LineWidth',3)
plot(vsort,meanc-stdc,'k:','LineWidth',3)

figure(2)
scatter(vol,coh./(rel.*20),'b','filled');
hold on
grid on
set(gca,'Yscale','log');
set(gca,'Xscale','log');



load('C:\Users\albertis\Desktop\Inpaint_nans\Results\Elk\output_sat_0_elk.mat');

phi=elk.phi_max;
coh=elk.c_max;
rel=elk.Relief;
thick=elk.MeanThickness;
VA=elk.VolumeAreaRatio;
vol=elk.Volume;
cnorm=coh./(thick.*20);


figure(1)
scatter(vol,coh./(thick.*20),'r','filled');
hold on

[vsort,idx]=sort(vol);
cnorm=cnorm(idx);
meanc=movmean(cnorm,100);

plot(vsort,meanc,'k','LineWidth',3)


figure(2)
scatter(vol,coh./(rel.*20),'b','filled');
hold on
grid on

