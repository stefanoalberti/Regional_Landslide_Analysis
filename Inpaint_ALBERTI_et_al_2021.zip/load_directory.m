function [myDir,myFiles,myDir_dem,myFiles_dem,myDir_ss,myFiles_ss,myDir_rain,myFiles_rain]=load_directory(type);


if type == "coastal"
%shapefile landslides
myDir='C:\Users\albertis\Desktop\Test_Model_Builder\Test Shear Zones\Singles\Singles_Merge';
myFiles = dir(fullfile(myDir,'*.shp')); %gets all wav files in struct
%shapefile deposit
%myDir_dep='C:\Users\albertis\Desktop\Test_Model_Builder\Test Shear
%Zones\Singles\Singles_deposits';
%myFiles_dep = dir(fullfile(myDir_dep,'*.shp')); %gets all wav files in struct
%dem landslides
myDir_dem='C:\Users\albertis\Desktop\Test_Model_Builder\Test Shear Zones\Singles\Singles_DEMs';
myFiles_dem = dir(fullfile(myDir_dem,'*.tif')); %gets all wav files in struct
%dem slip surfaces
myDir_ss='C:\Users\albertis\Desktop\Test_Model_Builder\Test Shear Zones\Singles\Singles_Slip_Surf';
myFiles_ss = dir(fullfile(myDir_ss,'*.tif')); %gets all wav files in struct

elseif  type == "bluff"   
%shapefile bluff
myDir='C:\Users\albertis\Desktop\Joanie_Regional\Shapefiles\Split';
myFiles = dir(fullfile(myDir,'*.shp')); %gets all wav files in struct
%shapefile deposit
%myDir_dep='C:\Users\albertis\Desktop\Test_Model_Builder\Test Shear
%Zones\Singles\Singles_deposits';
%myFiles_dep = dir(fullfile(myDir_dep,'*.shp')); %gets all wav files in struct
%dem landslides
myDir_dem='C:\Users\albertis\Desktop\Joanie_Regional\Shapefiles\Split\Raster\DEM';
myFiles_dem = dir(fullfile(myDir_dem,'*.tif')); %gets all wav files in struct
%dem slip surfaces
myDir_ss='C:\Users\albertis\Desktop\Joanie_Regional\Shapefiles\Split\Raster\Slip_surface';
myFiles_ss = dir(fullfile(myDir_ss,'*.tif')); %gets all wav files in struct

elseif  type == "bluff_total"   
%shapefile bluff
myDir='C:\Users\albertis\Desktop\Joanie_Regional\Shapefiles\Split\Total';
myFiles = dir(fullfile(myDir,'*.shp')); %gets all wav files in struct
%shapefile deposit
%myDir_dep='C:\Users\albertis\Desktop\Test_Model_Builder\Test Shear
%Zones\Singles\Singles_deposits';
%myFiles_dep = dir(fullfile(myDir_dep,'*.shp')); %gets all wav files in struct
%dem landslides
myDir_dem='C:\Users\albertis\Desktop\Joanie_Regional\Shapefiles\Split\Raster\DEM\Total';
myFiles_dem = dir(fullfile(myDir_dem,'*.tif')); %gets all wav files in struct
%dem slip surfaces
myDir_ss='C:\Users\albertis\Desktop\Joanie_Regional\Shapefiles\Split\Raster\Slip_surface\Total';
myFiles_ss = dir(fullfile(myDir_ss,'*.tif')); %gets all wav files in struct

elseif  type == "gales"   
%shapefile bluff
myDir='C:\Users\albertis\Downloads\GALES\Shapefiles\Single_shp'; %'C:\Users\albertis\Downloads\New folder\Area1\Split\Entire landslide\Repaired_Litho';
myFiles = dir(fullfile(myDir,'*.shp')); %gets all wav files in struct
%shapefile deposit
%myDir_dep='C:\Users\albertis\Desktop\Test_Model_Builder\Test Shear
%Zones\Singles\Singles_deposits';
%myFiles_dep = dir(fullfile(myDir_dep,'*.shp')); %gets all wav files in struct
%dem landslides
myDir_dem='C:\Users\albertis\Downloads\GALES\Raster\Singles_DEM'; %'C:\Users\albertis\Downloads\New folder\Area1\Split\DEM';
myFiles_dem = dir(fullfile(myDir_dem,'*.tif')); %gets all wav files in struct
%dem slip surfaces
myDir_ss='C:\Users\albertis\Downloads\GALES\Raster\Singles_SS'; %'C:\Users\albertis\Downloads\New folder\Area1\Split\Slip Surface';
myFiles_ss = dir(fullfile(myDir_ss,'*.tif')); %gets all wav files in struct
%rain
myDir_rain='C:\Users\albertis\Downloads\GALES\Raster\Singles_Rain';
myFiles_rain = dir(fullfile(myDir_rain,'*.tif'));

elseif  type == "elk"   
%shapefile bluff
myDir='C:\Users\albertis\Downloads\ELK\Shapefile\Single_shp';
myFiles = dir(fullfile(myDir,'*.shp')); %gets all wav files in struct
%shapefile deposit
%myDir_dep='C:\Users\albertis\Desktop\Test_Model_Builder\Test Shear
%Zones\Singles\Singles_deposits';
%myFiles_dep = dir(fullfile(myDir_dep,'*.shp')); %gets all wav files in struct
%dem landslides
myDir_dem='C:\Users\albertis\Downloads\ELK\Raster\Singles_DEM';
myFiles_dem = dir(fullfile(myDir_dem,'*.tif')); %gets all wav files in struct
%dem slip surfaces
myDir_ss='C:\Users\albertis\Downloads\ELK\Raster\Singles_SS';
myFiles_ss = dir(fullfile(myDir_ss,'*.tif')); %gets all wav files in struct
%rain
myDir_rain='C:\Users\albertis\Downloads\ELK\Raster\Singles_Rain';
myFiles_rain = dir(fullfile(myDir_rain,'*.tif'));

elseif  type == "brookings"   
%shapefile bluff
myDir='C:\Users\albertis\Downloads\BROOKINGS\Shapefiles\Single_shp';
myFiles = dir(fullfile(myDir,'*.shp')); %gets all wav files in struct
%shapefile deposit
%myDir_dep='C:\Users\albertis\Desktop\Test_Model_Builder\Test Shear
%Zones\Singles\Singles_deposits';
%myFiles_dep = dir(fullfile(myDir_dep,'*.shp')); %gets all wav files in struct
%dem landslides
myDir_dem='C:\Users\albertis\Downloads\BROOKINGS\Raster\Singles_DEM';
myFiles_dem = dir(fullfile(myDir_dem,'*.tif')); %gets all wav files in struct
%dem slip surfaces
myDir_ss='C:\Users\albertis\Downloads\BROOKINGS\Raster\Singles_SS';
myFiles_ss = dir(fullfile(myDir_ss,'*.tif')); %gets all wav files in struct
%rain
myDir_rain='C:\Users\albertis\Downloads\BROOKINGS\Raster\Singles_Rain';
myFiles_rain = dir(fullfile(myDir_rain,'*.tif'));

elseif  type == "florence"   
%shapefile bluff
myDir='C:\Users\albertis\Downloads\FLORENCE\Shapefiles\Single_shp';
myFiles = dir(fullfile(myDir,'*.shp')); %gets all wav files in struct
%shapefile deposit
%myDir_dep='C:\Users\albertis\Desktop\Test_Model_Builder\Test Shear
%Zones\Singles\Singles_deposits';
%myFiles_dep = dir(fullfile(myDir_dep,'*.shp')); %gets all wav files in struct
%dem landslides
myDir_dem='C:\Users\albertis\Downloads\FLORENCE\Raster\Singles_DEM';
myFiles_dem = dir(fullfile(myDir_dem,'*.tif')); %gets all wav files in struct
%dem slip surfaces
myDir_ss='C:\Users\albertis\Downloads\FLORENCE\Raster\Singles_SS';
myFiles_ss = dir(fullfile(myDir_ss,'*.tif')); %gets all wav files in struct
%rain
myDir_rain='C:\Users\albertis\Downloads\FLORENCE\Raster\Singles_Rain';
myFiles_rain = dir(fullfile(myDir_rain,'*.tif'));

elseif  type == "eugene"   
%shapefile bluff
myDir='C:\Users\albertis\Downloads\EUGENE\Shapefiles\Singles_shp';
myFiles = dir(fullfile(myDir,'*.shp')); %gets all wav files in struct
%shapefile deposit
%myDir_dep='C:\Users\albertis\Desktop\Test_Model_Builder\Test Shear
%Zones\Singles\Singles_deposits';
%myFiles_dep = dir(fullfile(myDir_dep,'*.shp')); %gets all wav files in struct
%dem landslides
myDir_dem='C:\Users\albertis\Downloads\EUGENE\Raster\Singles_DEM';
myFiles_dem = dir(fullfile(myDir_dem,'*.tif')); %gets all wav files in struct
%dem slip surfaces
myDir_ss='C:\Users\albertis\Downloads\EUGENE\Raster\Singles_SS';
myFiles_ss = dir(fullfile(myDir_ss,'*.tif')); %gets all wav files in struct
%rain
myDir_rain='C:\Users\albertis\Downloads\EUGENE\Raster\Singles_Rain';
myFiles_rain = dir(fullfile(myDir_rain,'*.tif'));

elseif  type == "vernonia"   
%shapefile bluff
myDir='C:\Users\albertis\Downloads\VERNONIA\Shapefiles\Singles_shp';
myFiles = dir(fullfile(myDir,'*.shp')); %gets all wav files in struct
%shapefile deposit
%myDir_dep='C:\Users\albertis\Desktop\Test_Model_Builder\Test Shear
%Zones\Singles\Singles_deposits';
%myFiles_dep = dir(fullfile(myDir_dep,'*.shp')); %gets all wav files in struct
%dem landslides
myDir_dem='C:\Users\albertis\Downloads\VERNONIA\Raster\Singles_DEM';
myFiles_dem = dir(fullfile(myDir_dem,'*.tif')); %gets all wav files in struct
%dem slip surfaces
myDir_ss='C:\Users\albertis\Downloads\VERNONIA\Raster\Singles_SS';
myFiles_ss = dir(fullfile(myDir_ss,'*.tif')); %gets all wav files in struct
%rain
myDir_rain='C:\Users\albertis\Downloads\VERNONIA\Raster\Singles_Rain';
myFiles_rain = dir(fullfile(myDir_rain,'*.tif'));

elseif  type == "clatskanie"   
%shapefile bluff
myDir='C:\Users\albertis\Downloads\CLATSKANIE\Shapefiles\Singles_shp';
myFiles = dir(fullfile(myDir,'*.shp')); %gets all wav files in struct
%shapefile deposit
%myDir_dep='C:\Users\albertis\Desktop\Test_Model_Builder\Test Shear
%Zones\Singles\Singles_deposits';
%myFiles_dep = dir(fullfile(myDir_dep,'*.shp')); %gets all wav files in struct
%dem landslides
myDir_dem='C:\Users\albertis\Downloads\CLATSKANIE\Raster\Singles_DEM';
myFiles_dem = dir(fullfile(myDir_dem,'*.tif')); %gets all wav files in struct
%dem slip surfaces
myDir_ss='C:\Users\albertis\Downloads\CLATSKANIE\Raster\Singles_SS';
myFiles_ss = dir(fullfile(myDir_ss,'*.tif')); %gets all wav files in struct
%rain
myDir_rain='C:\Users\albertis\Downloads\CLATSKANIE\Raster\Singles_Rain';
myFiles_rain = dir(fullfile(myDir_rain,'*.tif'));

elseif  type == "scottsburg"   
%shapefile bluff
myDir='C:\Users\albertis\Downloads\SCOTTSBURG\Shapefiles\Singles_shp';
myFiles = dir(fullfile(myDir,'*.shp')); %gets all wav files in struct
%shapefile deposit
%myDir_dep='C:\Users\albertis\Desktop\Test_Model_Builder\Test Shear
%Zones\Singles\Singles_deposits';
%myFiles_dep = dir(fullfile(myDir_dep,'*.shp')); %gets all wav files in struct
%dem landslides
myDir_dem='C:\Users\albertis\Downloads\SCOTTSBURG\Raster\Singles_DEM';
myFiles_dem = dir(fullfile(myDir_dem,'*.tif')); %gets all wav files in struct
%dem slip surfaces
myDir_ss='C:\Users\albertis\Downloads\SCOTTSBURG\Raster\Singles_SS';
myFiles_ss = dir(fullfile(myDir_ss,'*.tif')); %gets all wav files in struct
%rain
myDir_rain='C:\Users\albertis\Downloads\SCOTTSBURG\Raster\Singles_Rain';
myFiles_rain = dir(fullfile(myDir_rain,'*.tif'));

elseif  type == "north_coast"   
%shapefile bluff
myDir='C:\Users\albertis\Downloads\NORTHERN_COAST\Shapefiles\Singles_shp';
myFiles = dir(fullfile(myDir,'*.shp')); %gets all wav files in struct
%shapefile deposit
%myDir_dep='C:\Users\albertis\Desktop\Test_Model_Builder\Test Shear
%Zones\Singles\Singles_deposits';
%myFiles_dep = dir(fullfile(myDir_dep,'*.shp')); %gets all wav files in struct
%dem landslides
myDir_dem='C:\Users\albertis\Downloads\NORTHERN_COAST\Raster\Singles_DEM';
myFiles_dem = dir(fullfile(myDir_dem,'*.tif')); %gets all wav files in struct
%dem slip surfaces
myDir_ss='C:\Users\albertis\Downloads\NORTHERN_COAST\Raster\Singles_SS';
myFiles_ss = dir(fullfile(myDir_ss,'*.tif')); %gets all wav files in struct
%rain
myDir_rain='C:\Users\albertis\Downloads\NORTHERN_COAST\Raster\Singles_Rain';
myFiles_rain = dir(fullfile(myDir_rain,'*.tif'));

elseif  type == "south_coast_1"   
%shapefile bluff
myDir='C:\Users\albertis\Downloads\SOUTHERN_COAST\SUBDIVIDED\SOUTH_COAST_AREA1\Shapefiles\Singles_shp';
myFiles = dir(fullfile(myDir,'*.shp')); %gets all wav files in struct
%shapefile deposit
%myDir_dep='C:\Users\albertis\Desktop\Test_Model_Builder\Test Shear
%Zones\Singles\Singles_deposits';
%myFiles_dep = dir(fullfile(myDir_dep,'*.shp')); %gets all wav files in struct
%dem landslides
myDir_dem='C:\Users\albertis\Downloads\SOUTHERN_COAST\SUBDIVIDED\SOUTH_COAST_AREA1\Raster\Singles_DEM';
myFiles_dem = dir(fullfile(myDir_dem,'*.tif')); %gets all wav files in struct
%dem slip surfaces
myDir_ss='C:\Users\albertis\Downloads\SOUTHERN_COAST\SUBDIVIDED\SOUTH_COAST_AREA1\Raster\Singles_SS';
myFiles_ss = dir(fullfile(myDir_ss,'*.tif')); %gets all wav files in struct

elseif  type == "south_coast_2"   
%shapefile bluff
myDir='C:\Users\albertis\Downloads\SOUTHERN_COAST\SUBDIVIDED\SOUTH_COAST_AREA2\Shapefiles\Singles_shp';
myFiles = dir(fullfile(myDir,'*.shp')); %gets all wav files in struct
%shapefile deposit
%myDir_dep='C:\Users\albertis\Desktop\Test_Model_Builder\Test Shear
%Zones\Singles\Singles_deposits';
%myFiles_dep = dir(fullfile(myDir_dep,'*.shp')); %gets all wav files in struct
%dem landslides
myDir_dem='C:\Users\albertis\Downloads\SOUTHERN_COAST\SUBDIVIDED\SOUTH_COAST_AREA2\Raster\Singles_DEM';
myFiles_dem = dir(fullfile(myDir_dem,'*.tif')); %gets all wav files in struct
%dem slip surfaces
myDir_ss='C:\Users\albertis\Downloads\SOUTHERN_COAST\SUBDIVIDED\SOUTH_COAST_AREA2\Raster\Singles_SS';
myFiles_ss = dir(fullfile(myDir_ss,'*.tif')); %gets all wav files in struct

elseif  type == "south_coast_3"   
%shapefile bluff
myDir='C:\Users\albertis\Downloads\SOUTHERN_COAST\SUBDIVIDED\SOUTH_COAST_AREA3\Shapefiles\Singles_shp';
myFiles = dir(fullfile(myDir,'*.shp')); %gets all wav files in struct
%shapefile deposit
%myDir_dep='C:\Users\albertis\Desktop\Test_Model_Builder\Test Shear
%Zones\Singles\Singles_deposits';
%myFiles_dep = dir(fullfile(myDir_dep,'*.shp')); %gets all wav files in struct
%dem landslides
myDir_dem='C:\Users\albertis\Downloads\SOUTHERN_COAST\SUBDIVIDED\SOUTH_COAST_AREA3\Raster\Singles_DEM';
myFiles_dem = dir(fullfile(myDir_dem,'*.tif')); %gets all wav files in struct
%dem slip surfaces
myDir_ss='C:\Users\albertis\Downloads\SOUTHERN_COAST\SUBDIVIDED\SOUTH_COAST_AREA3\Raster\Singles_SS';
myFiles_ss = dir(fullfile(myDir_ss,'*.tif')); %gets all wav files in struct

elseif  type == "south_coast"   
%shapefile bluff
myDir='C:\Users\albertis\Downloads\SOUTHERN_COAST\Shapefiles\Singles_shp';
myFiles = dir(fullfile(myDir,'*.shp')); %gets all wav files in struct
%shapefile deposit
%myDir_dep='C:\Users\albertis\Desktop\Test_Model_Builder\Test Shear
%Zones\Singles\Singles_deposits';
%myFiles_dep = dir(fullfile(myDir_dep,'*.shp')); %gets all wav files in struct
%dem landslides
myDir_dem='C:\Users\albertis\Downloads\SOUTHERN_COAST\Raster\Singles_DEM';
myFiles_dem = dir(fullfile(myDir_dem,'*.tif')); %gets all wav files in struct
%dem slip surfaces
myDir_ss='C:\Users\albertis\Downloads\SOUTHERN_COAST\Raster\Singles_SS';
myFiles_ss = dir(fullfile(myDir_ss,'*.tif')); %gets all wav files in struct
%rain
myDir_rain='C:\Users\albertis\Downloads\SOUTHERN_COAST\Raster\Singles_Rain';
myFiles_rain = dir(fullfile(myDir_rain,'*.tif'));

elseif  type == "salem_east"   
%shapefile bluff
myDir='C:\Users\albertis\Downloads\SALEM\SUBDIVIDED\SALEM_EAST\Shapefiles\Singles_shp';
myFiles = dir(fullfile(myDir,'*.shp')); %gets all wav files in struct
%shapefile deposit
%myDir_dep='C:\Users\albertis\Desktop\Test_Model_Builder\Test Shear
%Zones\Singles\Singles_deposits';
%myFiles_dep = dir(fullfile(myDir_dep,'*.shp')); %gets all wav files in struct
%dem landslides
myDir_dem='C:\Users\albertis\Downloads\SALEM\SUBDIVIDED\SALEM_EAST\Raster\Singles_DEM';
myFiles_dem = dir(fullfile(myDir_dem,'*.tif')); %gets all wav files in struct
%dem slip surfaces
myDir_ss='C:\Users\albertis\Downloads\SALEM\SUBDIVIDED\SALEM_EAST\Raster\Singles_SS';
myFiles_ss = dir(fullfile(myDir_ss,'*.tif')); %gets all wav files in struct

elseif  type == "salem_west"   
%shapefile bluff
myDir='C:\Users\albertis\Downloads\SALEM\SUBDIVIDED\SALEM_WEST\Shapefiles\Singles_shp';
myFiles = dir(fullfile(myDir,'*.shp')); %gets all wav files in struct
%shapefile deposit
%myDir_dep='C:\Users\albertis\Desktop\Test_Model_Builder\Test Shear
%Zones\Singles\Singles_deposits';
%myFiles_dep = dir(fullfile(myDir_dep,'*.shp')); %gets all wav files in struct
%dem landslides
myDir_dem='C:\Users\albertis\Downloads\SALEM\SUBDIVIDED\SALEM_WEST\Raster\Singles_DEM';
myFiles_dem = dir(fullfile(myDir_dem,'*.tif')); %gets all wav files in struct
%dem slip surfaces
myDir_ss='C:\Users\albertis\Downloads\SALEM\SUBDIVIDED\SALEM_WEST\Raster\Singles_SS';
myFiles_ss = dir(fullfile(myDir_ss,'*.tif')); %gets all wav files in struct

elseif  type == "salem"   
%shapefile bluff
myDir='C:\Users\albertis\Downloads\SALEM\Shapefiles\Singles_shp';
myFiles = dir(fullfile(myDir,'*.shp')); %gets all wav files in struct
%shapefile deposit
%myDir_dep='C:\Users\albertis\Desktop\Test_Model_Builder\Test Shear
%Zones\Singles\Singles_deposits';
%myFiles_dep = dir(fullfile(myDir_dep,'*.shp')); %gets all wav files in struct
%dem landslides
myDir_dem='C:\Users\albertis\Downloads\SALEM\Raster\Single_DEM';
myFiles_dem = dir(fullfile(myDir_dem,'*.tif')); %gets all wav files in struct
%dem slip surfaces
myDir_ss='C:\Users\albertis\Downloads\SALEM\Raster\Singles_SS';
myFiles_ss = dir(fullfile(myDir_ss,'*.tif')); %gets all wav files in struct
%rain
myDir_rain='C:\Users\albertis\Downloads\SALEM\Raster\Singles_Rain';
myFiles_rain = dir(fullfile(myDir_rain,'*.tif'));

elseif  type == "portl_2"   
%shapefile bluff
myDir='C:\Users\albertis\Downloads\CASCADE\PORTLAND_AREA2\Shapefiles\Singles_shp';
myFiles = dir(fullfile(myDir,'*.shp')); %gets all wav files in struct
%shapefile deposit
%myDir_dep='C:\Users\albertis\Desktop\Test_Model_Builder\Test Shear
%Zones\Singles\Singles_deposits';
%myFiles_dep = dir(fullfile(myDir_dep,'*.shp')); %gets all wav files in struct
%dem landslides
myDir_dem='C:\Users\albertis\Downloads\CASCADE\PORTLAND_AREA2\Raster\Singles_DEM';
myFiles_dem = dir(fullfile(myDir_dem,'*.tif')); %gets all wav files in struct
%dem slip surfaces
myDir_ss='C:\Users\albertis\Downloads\CASCADE\PORTLAND_AREA2\Raster\Singles_SS';
myFiles_ss = dir(fullfile(myDir_ss,'*.tif')); %gets all wav files in struct
%rain
myDir_rain='C:\Users\albertis\Downloads\CASCADE\PORTLAND_AREA2\Raster\Singles_Rain';
myFiles_rain = dir(fullfile(myDir_rain,'*.tif'));

elseif  type == "portl_3"   
%shapefile bluff
myDir='C:\Users\albertis\Downloads\CASCADE\PORTLAND_AREA3\Shapefiles\Singles_shp';
myFiles = dir(fullfile(myDir,'*.shp')); %gets all wav files in struct
%shapefile deposit
%myDir_dep='C:\Users\albertis\Desktop\Test_Model_Builder\Test Shear
%Zones\Singles\Singles_deposits';
%myFiles_dep = dir(fullfile(myDir_dep,'*.shp')); %gets all wav files in struct
%dem landslides
myDir_dem='C:\Users\albertis\Downloads\CASCADE\PORTLAND_AREA3\Raster\Singles_DEM';
myFiles_dem = dir(fullfile(myDir_dem,'*.tif')); %gets all wav files in struct
%dem slip surfaces
myDir_ss='C:\Users\albertis\Downloads\CASCADE\PORTLAND_AREA3\Raster\Singles_SS';
myFiles_ss = dir(fullfile(myDir_ss,'*.tif')); %gets all wav files in struct
%rain
myDir_rain='C:\Users\albertis\Downloads\CASCADE\PORTLAND_AREA3\Raster\Singles_Rain';
myFiles_rain = dir(fullfile(myDir_rain,'*.tif'));

end





