
%% Main Script
close all;
clear all;
clc;

%% Load directory
% type = "brookings"; %bluff % coastal %regional %gales %bluff_total %elk %brookings
type0 = {'gales';
    'florence';
    'clatskanie';
    'eugene';
    'vernonia';
    'portl_2';
    'portl_3';
    'scottsburg';
    'salem';
    'elk';
    'south_coast';
    'north_coast';
};
    %bluff % coastal %regional %gales %bluff_total %elk %brookings
% Saturationd degree
%sat=[0]; %0 0.5 1

%% Save Profiles
saveprofile=0; %1Y %0N 

%% Skip Stability 
justgeomorph=0; %1Y %0N

%% Reconstructed (w/ inpaiting) or Original surfaces
%rec_surf=0; %if 1 use inpainting function, if 0 use normal slope

%%
PGA="9.0"; %0 8.1 8.4 8.7 or 9.0, "savePGA"

%%
writetiff=0; %if 1 save also geotiff of reconstructed surface

%% run code with different saturation degrees

for i=1:length(type0)

    type=type0(i);
    
for    rec_surf=[0 1]
    
for sat=[0.5 0] %[0 0.5 1]

[~]=function_testing(type,sat,saveprofile,rec_surf,PGA,justgeomorph);

end 

end

end


%% Save Shapefiles


%% Save data inside a structure
% Shapefiles
% path='N:\';
% ba_shp = fullfile(path,'test',FileName);
% shapewrite(export_shp,ba_shp);


% %% save for shapefile
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% export_shp(i)=roi;
% %export_shp.Geometry(i,:)=roi.Geometry;
% %export_shp.BoundingBox(i,:)=roi.BoundingBox;
% %export_shp.X(i)=roi.X;
% %export_shp.Y(i)=roi.Y;
% %export_shp.UNIQUE_ID(i)=roi.UNIQUE_ID;
% %export_shp.Shape_Leng(i)=roi.Shape_Leng;
% export_shp.rel(i)=relief; 
% export_shp.area(i)=area;
% export_shp.area_sh(i)=area_sh;
% export_shp.vol(i)=vol;
% export_shp.vol_sh(i)=volume_sh;
% export_shp.AR(i)=AR;
% export_shp.AR_rg(i)=AR_rg;
% export_shp.asp_avg(i)=Aspect_avg;
% export_shp.sl_avg(i)=Slope_avg;
% export_shp.rot(i)=rot;
% export_shp.el_avg(i)=Elevation_avg;
% export_shp.max_thick(i)=Max_thick;
% export_shp.avg_thick(i)=Thick_avg;
% export_shp.med_thick(i)=Median_Thick;
% export_shp.sd_thick(i)=SD_Thick;
% %export_shp.reg_prop(i,:)=reg_prop;
% %export_shp.name(i,:)=cellstr(baseFileName);
% export_shp.c_max(i)=double(c_max*pst_to_kPa); % store
% export_shp.phi_max(i)=double(phi_max); % store
% %export_shp.phi_test(:,i)=double(phi_test); % store
% %export_shp.cf(:,i)=cf*pst_to_kPa; % store
% %export_shp.R_ref(i,:)=R_arizona; % store
% export_shp.litho(i)=cellstr(litho); % store
% export_shp.move_class(i)=cellstr(mov_class); % store
% export_shp.VA(i)=VA; % volume/area store 
% 
% %export_shp=repmat(export_shp, size(struct2table(myFiles),1),size(struct2table(myFiles),2));
% %export_shp_store=[export_shp_store;export_shp];
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%