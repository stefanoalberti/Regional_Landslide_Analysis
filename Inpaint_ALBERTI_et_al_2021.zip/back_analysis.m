function [c_max,phi_max,phi_test,cf,rot]=back_analysis(Zbool, dxtemp, Slope_ss, Aspect, asp, ...
    c0, phi0, W0, ~, gs, kx, ky, Ex, Ey, VA, sat)

pwp=(W0./(dxtemp.^2)).*sat.*62.4;

sum(Zbool);
Zbool=W0;
Zbool(Zbool>0)=1;
sum(Zbool);
Slope_ss(isnan(Slope_ss))=0;
%VA=10; %was 10

c0=0;
% Run Slope Stability Analysis with simple Janbu, get max phi
[rot, phi_max, cf, iter0] = SimpJanbu3D(Zbool, dxtemp, Slope_ss, Aspect, asp, ...
    c0, phi0, W0, pwp, gs, 'phi', kx, ky, Ex, Ey,VA);

c_max=0;


iter=1;
if phi_max==0 || isnan(phi_max)
c_max=0;    
else
    
    while c_max==0
    phi0=0;
    % Run Slope Stability Analysis with simple Janbu, get max c
    [rot, phii, c_max, iter0] = SimpJanbu3D(Zbool, dxtemp, Slope_ss, Aspect, asp, ...
        c0, phi0, W0, pwp, gs, 'c', kx, ky, Ex, Ey,VA);


    if iter>5
       break 
    else
    VA=VA/4;
    iter=iter+1;
    end
    
    end
end

phi_test=linspace(0,phi_max,10);

%VA=(c_max/length(phi_test))/4;



c0=0;
%tic
if phi_max==0 || c_max==0 || isnan(phi_max) || isnan(c_max)
cf=zeros(size(phi_test));   
else

 for p=1:length(phi_test)
     
     phi0=phi_test(p);
    VA=0.015*(1-p/(length(phi_test)+1)).*c_max;
     
    if p==length(phi_test)
    rot=0;
    phi=phi_max;
    cf(p,1)=0;
    else
            
    [rot, phi, cf(p,1), iter0] = SimpJanbu3D(Zbool, dxtemp, Slope_ss, Aspect, asp, ...
    c0, phi0, W0, pwp, gs, 'c', kx, ky, Ex, Ey,VA);
    end
    end
 
 
end

phi_test=phi_test.';

%toc

 end

 
 