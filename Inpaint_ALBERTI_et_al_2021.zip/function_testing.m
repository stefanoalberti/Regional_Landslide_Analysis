function [sat]=function_testing(type,sat,saveprofile,rec_surf,PGA,justgeomorph)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                                                            %
%                                                                                                            %
%                                                                                                            %
%                                                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

skipped = [];

%% Load directory and PGA 
[myDir,myFiles,myDir_dem,myFiles_dem,myDir_ss,myFiles_ss,myDir_rain,myFiles_rain]=load_directory(type);

if PGA~="0" 
[myDir_PGA,myFiles_PGA]=load_directory_PGA(PGA,type);
end

%% Method for Nan's interpolation 
method = 2; %1-4

% Saturationd degree
sat=sat; %0 0.5 1

%% Save Profiles
%saveprofile=0; % 1 Y % 0 N

%% Save Geotiff
writetiff=0;

%% Start cycle 
for i = 1:size(struct2table(myFiles),1) %694 %588 %lengths 
  tic
  baseFileName = myFiles(i).name;
  fullFileName = fullfile(myDir, baseFileName);
  FileName=extractBefore(baseFileName,".");
  %baseFileName_dep = myFiles_dep(i).name;
  %fullFileName_dep = fullfile(myDir_dep, baseFileName_dep);
  baseFileName_dem = myFiles_dem(i).name;
  fullFileName_dem = fullfile(myDir_dem, baseFileName_dem);
  baseFileName_ss = myFiles_ss(i).name;
  fullFileName_ss = fullfile(myDir_ss, baseFileName_ss);
  %rain
  baseFileName_rain = myFiles_rain(i).name;
  fullFileName_rain = fullfile(myDir_rain, baseFileName_rain);
  % PGA
  if PGA~="0"
  baseFileName_PGA = myFiles_PGA(i).name;
  fullFileName_PGA = fullfile(myDir_PGA, baseFileName_PGA);
  end
  
  % was length instead size
 print_text = ['Now processing landslide ', FileName,' ', '\\',' Number',' ', num2str(i),'/',num2str(size(myFiles,1)),' - ', char(type), ' - PGA ', char(PGA),' - sat ', num2str(sat), ' - reconstr:',num2str(rec_surf),' - ' ];
 fprintf(print_text)
  
  %% Check if three source files are the same before to go head 
  shp_name=extractBefore(baseFileName,".");
  dem_name=extractBefore(baseFileName_dem,".");
  ss_name=extractBefore(baseFileName_ss,".");
  % 
  check1=strcmp(shp_name,dem_name);
  check2=strcmp(dem_name,ss_name);
    
  if  check1==check2 
  %% Import data 
% DEM
 if PGA~="0" 
[R_arizona,Z_arizona,Zss,Rss,x_cellsize_arizona,y_cellsize_arizona,...
    nx_arizona,ny_arizona,Xarizona,Yarizona,Z_PGA,Z_rain]=process_DEM(fullFileName_ss,fullFileName_dem,PGA,fullFileName_rain,fullFileName_PGA);
 elseif PGA=="savePGA"
 [R_arizona,Z_arizona,Zss,Rss,x_cellsize_arizona,y_cellsize_arizona,...
    nx_arizona,ny_arizona,Xarizona,Yarizona,Z_PGA,Z_rain]=process_DEM(fullFileName_ss,fullFileName_dem,PGA,fullFileName_rain,fullFileName_PGA);    
 else
 [R_arizona,Z_arizona,Zss,Rss,x_cellsize_arizona,y_cellsize_arizona,...
   nx_arizona,ny_arizona,Xarizona,Yarizona,Z_PGA,Z_rain]=process_DEM(fullFileName_ss,fullFileName_dem,PGA,fullFileName_rain);
 end

% Create Boolean mask    
DEM_area = fullFileName_dem;
R = geotiffinfo(DEM_area);
[x,y] = pixcenters(R); 
% Convert x,y arrays to grid - region of interest : sempre de
[X,Y] = meshgrid(x,y);
roi = shaperead(fullFileName);
% Remove trailing nan from shapefile
rx = roi.X(1:end-1);
ry = roi.Y(1:end-1);
% boolean mask
mask_bool_logical = inpolygon(X,Y,rx,ry); % generate boolean values to indicate in/outside landslide
mask_bool_logical=bwmorph(mask_bool_logical,'thicken',1); %1
mask_bool_double=double(mask_bool_logical);

% Prepare DEM 
Z_arizona(isnan(Z_arizona))=0; % replace NaN values w/ 0 usually we use
%this option
%Z_arizona(Z_arizona<=0)=NaN; % add on 05/25/2021
Ztemp=Z_arizona.*mask_bool_logical;
Ztemp(Ztemp>0)=NaN;
Ztemp(Ztemp==0)=1;
Ztemp=Ztemp.*Z_arizona;

%% do inpainting 
% Z_inp2=fillmissing(Ztemp,'linear',2); % test
% Z_inp1=fillmissing(Ztemp,'linear',1); % test
% Z_inp=(Z_inp2+Z_inp1)/2; % test

%[Z_inp]=inpaintn(Ztemp,1000);
if rec_surf==1
[Z_inp]=inpaint_nans_bc(Ztemp,0,'toroid');
Z_arizona=Z_inp;
else
Z_inp=Z_arizona;    
end

% Rainfall
rainf=mean(Z_rain,'all','omitnan'); %% mm i'm quite sure

% Check vol area Guzzetti et al. 
h=(Z_inp-Zss).*mask_bool_logical; h(h<0)=0; 
vol=sum(20.*20.*mask_bool_logical.*h,'all','omitnan')./(3.28^3); % vol in m^3
abool=sign(h); abool(isnan(abool))=0;
area=sum(20.*20.*mask_bool_logical.*abool,'all','omitnan')./(3.28^2); % area in m^2
% area=sum(20.*20.*mask_bool_logical,'all')./(3.28^2); % area in m^2
ratio=vol./(0.074*(area^1.45)); % ratio volume extracted/volume by Guzzetti
VA=vol./area;
out(i,:)= [area vol ratio VA]; % store values of area and volume


cguess=VA./0.05; % 0.05

%back-analysis
cellsize=R_arizona.CellExtentInWorldX;
[Slope,Aspect,dx,dy] = gradient_king(Z_inp,R_arizona);
[Slope_ss,Aspect_ss,dx_ss,dy_ss] = gradient_king(Zss,R_arizona);

if PGA=="0"
kx=0; ky=0; Ex=0; Ey=0; PGAsave=0;
elseif PGA=="savePGA"
kx=0; ky=0; Ex=0; Ey=0; 
PGAsave=mean(Z_PGA,'all','omitnan');
else
ky=mean(Z_PGA,'all','omitnan');
ky(isnan(ky))=0;
kx=0; Ex=0; Ey=0;
PGAsave=ky;
end

%kx=0; ky=0; Ex=0; Ey=0;
gs=127;
gw=62.4;
c0=0; phi0=0;
asp=mean(Aspect(mask_bool_logical==1),'all','omitnan');
W0=cellsize.*cellsize.*h; W0(isnan(W0))=0;

%sat=0; %0 0.5 1
pst_to_kPa=0.047880258888889;

%% Check DEM/slip surface 
a=Z_arizona-Zss;
S = sum( a , 'all','omitnan'); 
if S>0    
%% back analysis
%[c_max,phi_max,phi_test,cf,rot]=back_analysis(mask_bool_logical(:), cellsize(:), Slope_ss(:), Aspect(:), asp(:),...
    %c0(:), phi0(:), W0(:), 0, gs(:), kx(:), ky(:), Ex(:), Ey(:),cguess, sat);
    
%%%% add 05/25/2021 just for Ben
 if justgeomorph==1
 c_max=0;
 phi_max=0;
 phi_test=0;
 cf=0;
 rot=0;
 elseif justgeomorph==0
 [c_max,phi_max,phi_test,cf,rot]=back_analysis(mask_bool_logical(:), cellsize(:), Slope_ss(:), Aspect(:), asp(:),...
     c0(:), phi0(:), W0(:), 0, gs(:), kx(:), ky(:), Ex(:), Ey(:),cguess, sat);
  end
 
%% extract geomorph parameters 

%[relief,area_sh,volume_sh,AR,Aspect_avg,Slope_avg,Elevation_avg,Max_thick,Thick_avg,...
    %Median_Thick,SD_Thick,reg_prop,litho,mov_class,AR_rg,zss_e,zsurf_e,length_profile,max_length,max_length_rg,Slope_ss_avg,MinEl,MaxEl] = extract_parameters(Z_arizona,Zss,...
    %mask_bool_double,roi,Aspect,Slope,Slope_ss,type,cellsize,X,Y,Z_inp); % meters 
    
%[relief,area_sh,volume_sh,AR,Aspect_avg,Slope_avg,Elevation_avg,Max_thick,Thick_avg,...
    %Median_Thick,SD_Thick,reg_prop,litho,mov_class,AR_rg,zss_e,zsurf_e,length_profile,max_length,max_length_rg,Slope_ss_avg,MinEl,MaxEl] = extract_parameters_ben(Z_arizona,Zss,...
    %mask_bool_double,roi,Aspect,Slope,Slope_ss,type,cellsize,X,Y,Z_inp); % meters 

[relief,area_sh,volume_sh,AR,Aspect_avg,Slope_avg,Elevation_avg,Max_thick,Thick_avg,Median_Thick,SD_Thick,reg_prop,litho,mov_class,AR_rg,zss_e,zsurf_e,length,max_length,max_length_rg,Slope_ss_avg,MinEl,MaxEl] ...
    = extract_parameters_BAL(Z_arizona,Zss,mask_bool_double,roi,Aspect,Slope,Slope_ss,type,cellsize,X,Y,Z_inp,abool);


%% Save DEM for recostructed surface
% path = 'N:\'
% FileNameTif=strcat(FileName,'.tif');
% DEM_out = fullfile(path, FileNameTif, '.tif');
% geotiffwrite(DEM_out,Z_inp,R_arizona,'CoordRefSysCode',26912);

%
if writetiff==1;
myDir_dem_rec=('C:\Users\albertis\Desktop\Inpaint_nans\DEM_rec');
fullFileName_dem_rec = fullfile(myDir_dem_rec, baseFileName_dem);
geotiffwrite(fullFileName_dem_rec ,Z_inp,R_arizona,'CoordRefSysCode',26912) %26912
end

% save profiles
if saveprofile==1;
zss_e=zss_e';
zsurf_e=zsurf_e';
length_profile=length_profile';
Z_prof = [length_profile zsurf_e zss_e];
pathProf='C:\Users\albertis\Desktop\Inpaint_nans\Profiles\'
FileNameCsvProf=strcat(pathProf,FileName,'.csv');
csvwrite(FileNameCsvProf,Z_prof);
end 

% save variable to export
out_zone(i,:)=cellstr(type);
out_rel(i,:)=relief; 
out_area(i,:)=area;
out_area_sh(i,:)=area_sh;
out_vol(i,:)=vol;
out_vol_sh(i,:)=volume_sh;
out_AR(i,:)=AR;
out_AR_rg(i,:)=AR_rg;
out_asp_avg(i,:)=Aspect_avg;
out_sl_avg(i,:)=Slope_avg;
out_sl_ss_avg(i,:)=Slope_ss_avg; %% Slope slip surface
out_rot(i,:)=rot;
out_el_avg(i,:)=Elevation_avg;
out_max_thick(i,:)=Max_thick;
out_avg_thick(i,:)=Thick_avg;
out_med_thick(i,:)=Median_Thick;
out_sd_thick(i,:)=SD_Thick;
out_reg_prop(i,:)=reg_prop;
out_name(i,:)=cellstr(FileName);
out_c_max(i,:)=double(c_max*pst_to_kPa); % store
out_phi_max(i,:)=double(phi_max); % store
out_phi_test(:,i)=double(phi_test); % store
out_cf(:,i)=cf*pst_to_kPa; % store
out_R_ref(i,:)=R_arizona; % store
out_litho(i,:)=cellstr(litho); % store
out_move_class(i,:)=cellstr(mov_class); % store
out_VA(i,:)=VA; % volume/area store 
out_l_max(i,:)=max_length; % max length w/ bounding box
out_l_max_rg(i,:)=max_length_rg; % max length from region properties function
out_PGA(i,:)=PGAsave;
out_rain(i,:)=rainf;
out_min_el(i,:)=MinEl;
out_max_el(i,:)=MaxEl;

% %% save for shapefile
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% export_shp(i)=roi;
% %export_shp.Geometry(i,:)=roi.Geometry;
% %export_shp.BoundingBox(i,:)=roi.BoundingBox;
% %export_shp.X(i)=roi.X;
% %export_shp.Y(i)=roi.Y;
% %export_shp.UNIQUE_ID(i)=roi.UNIQUE_ID;
% %export_shp.Shape_Leng(i)=roi.Shape_Leng;
% export_shp.rel(i)=relief; 
% export_shp.area(i)=area;
% export_shp.area_sh(i)=area_sh;
% export_shp.vol(i)=vol;
% export_shp.vol_sh(i)=volume_sh;
% export_shp.AR(i)=AR;
% export_shp.AR_rg(i)=AR_rg;
% export_shp.asp_avg(i)=Aspect_avg;
% export_shp.sl_avg(i)=Slope_avg;
% export_shp.rot(i)=rot;
% export_shp.el_avg(i)=Elevation_avg;
% export_shp.max_thick(i)=Max_thick;
% export_shp.avg_thick(i)=Thick_avg;
% export_shp.med_thick(i)=Median_Thick;
% export_shp.sd_thick(i)=SD_Thick;
% %export_shp.reg_prop(i,:)=reg_prop;
% %export_shp.name(i,:)=cellstr(baseFileName);
% export_shp.c_max(i)=double(c_max*pst_to_kPa); % store
% export_shp.phi_max(i)=double(phi_max); % store
% %export_shp.phi_test(:,i)=double(phi_test); % store
% %export_shp.cf(:,i)=cf*pst_to_kPa; % store
% %export_shp.R_ref(i,:)=R_arizona; % store
% export_shp.litho(i)=cellstr(litho); % store
% export_shp.move_class(i)=cellstr(mov_class); % store
% export_shp.VA(i)=VA; % volume/area store 
% 
% %export_shp=repmat(export_shp, size(struct2table(myFiles),1),size(struct2table(myFiles),2));
% %export_shp_store=[export_shp_store;export_shp];
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


elseif S<0
name=cellstr(FileName); 
skipped = [skipped; name];
end

toc

  else
      break
  end
end


%% Save data inside a structure
% Shapefiles
% path='N:\';
% ba_shp = fullfile(path,'test',FileName);
% shapewrite(export_shp,ba_shp);

% Structure
%out_temp = strcat('output_sat',num2str(sat));

output_sat0.zone=out_zone;
output_sat0.name=out_name;
output_sat0.c_max=out_c_max;
output_sat0.phi_max=out_phi_max;
output_sat0.phi_test=out_phi_test;
output_sat0.cf=out_cf;
output_sat0.Reference=out_R_ref;
output_sat0.Saturat=sat;
output_sat0.Relief=out_rel;
output_sat0.Area_sh=out_area_sh;
output_sat0.Area=out_area;
output_sat0.Volume_sh=out_vol_sh;
output_sat0.Volume=out_vol;
output_sat0.AR=out_AR;
output_sat0.AR_rg=out_AR_rg;
output_sat0.AspectAVG=out_asp_avg;
output_sat0.SlopeAVG=out_sl_avg;
output_sat0.SlopeSsAVG=out_sl_ss_avg;
output_sat0.Rot=out_rot;
output_sat0.ElevationAVG=out_el_avg;
output_sat0.MaxThickness=out_max_thick;
output_sat0.MeanThickness=out_avg_thick;
output_sat0.MedianThickness=out_med_thick;
output_sat0.SDThickness=out_sd_thick;
output_sat0.VolumeAreaRatio=out_VA;
output_sat0.MoveClass=out_move_class;
output_sat0.Lithology=out_litho;
output_sat0.max_length=out_l_max;
output_sat0.max_length_rg=out_l_max_rg;
output_sat0.PGA=out_PGA;
output_sat0.rain=out_rain;
output_sat0.MinEl=out_min_el;
output_sat0.MaxEl=out_max_el;

%output_sat0.reg_prop=out_reg_prop;

%output_sat0=struct('Name',out_name,'c_max',out_c_max,'phi_max',out_phi_max,'phi_test',
%out_phi_test, 'cf', out_cf,'Reference', out_R_ref,'Saturat', sat,'Relief',out_rel,'Area', out_area,'Volume',out_vol,'AR',out_AR,'AspectAVG',out_asp_avg,'SlopeAVG',out_sl_avg,'Rot',out_rot,'ElevationAVG',out_el_avg,'MaxThickness',out_max_thick,'MeanThickness',out_avg_thick,'MedianThickness',out_med_thick,'SDThickness',out_sd_thick,'VolumeAreaRatio',out_VA,'MoveClass',out_move_class,'Lithology',out_litho);

% export
if PGA=="0" && PGA=="savePGA" 
    if rec_surf==1
    FileNameSave=string(strcat('output_sat_',num2str(sat),'_',type,'_rec'));
    save(FileNameSave,'output_sat0');
    elseif rec_surf==0
    FileNameSave_no_rec=string(strcat('output_sat_',num2str(sat),'_',type,'_no_rec'));
    save(FileNameSave_no_rec,'output_sat0'); 
    end   
else
   if rec_surf==1
    FileNameSave=string(strcat('output_sat_',num2str(sat),'_',type,'_rec_PGA_',PGA));
    save(FileNameSave,'output_sat0');
    elseif rec_surf==0
    FileNameSave_no_rec=string(strcat('output_sat_',num2str(sat),'_',type,'_no_rec_PGA_',PGA));
    save(FileNameSave_no_rec,'output_sat0'); 
    end 

end







end








