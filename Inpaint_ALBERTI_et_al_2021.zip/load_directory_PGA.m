function [myDir_PGA,myFiles_PGA]=load_directory_PGA(PGA,type);

%% PORTLAND 2 - PORTLAND HILLS
if PGA=="8.1" && type=="portl_2"
myDir_PGA='C:\Users\albertis\Downloads\CASCADE\PORTLAND_AREA2\Raster\Singles_PGA_81';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct   
elseif  PGA=="8.4" && type=="portl_2"
myDir_PGA='C:\Users\albertis\Downloads\CASCADE\PORTLAND_AREA2\Raster\Singles_PGA_84';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct   
elseif  PGA=="8.7" && type=="portl_2"
myDir_PGA='C:\Users\albertis\Downloads\CASCADE\PORTLAND_AREA2\Raster\Singles_PGA_87';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct   
elseif  PGA=="9.0" && type=="portl_2"
myDir_PGA='C:\Users\albertis\Downloads\CASCADE\PORTLAND_AREA2\Raster\Singles_PGA_90';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct 
elseif PGA=="savePGA" && type=="portl_2"
myDir_PGA='C:\Users\albertis\Downloads\CASCADE\PORTLAND_AREA2\Raster\Singles_PGA_90';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct     
end

%% PORTLAND 3 - CLACKAMAS
if PGA=="8.1" && type=="portl_3"
myDir_PGA='C:\Users\albertis\Downloads\CASCADE\PORTLAND_AREA3\Raster\Singles_PGA_81';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct   
elseif  PGA=="8.4" && type=="portl_3"
myDir_PGA='C:\Users\albertis\Downloads\CASCADE\PORTLAND_AREA3\Raster\Singles_PGA_84';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct   
elseif  PGA=="8.7" && type=="portl_3"
myDir_PGA='C:\Users\albertis\Downloads\CASCADE\PORTLAND_AREA3\Raster\Singles_PGA_87';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct   
elseif  PGA=="9.0" && type=="portl_3"
myDir_PGA='C:\Users\albertis\Downloads\CASCADE\PORTLAND_AREA3\Raster\Singles_PGA_90';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct  
elseif PGA=="savePGA" && type=="portl_3"
myDir_PGA='C:\Users\albertis\Downloads\CASCADE\PORTLAND_AREA3\Raster\Singles_PGA_90';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct   
end

%% CLATSKANIE
if PGA=="8.1" && type=="clatskanie"
myDir_PGA='C:\Users\albertis\Downloads\CLATSKANIE\Raster\Singles_PGA_81';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct   
elseif  PGA=="8.4" && type=="clatskanie"
myDir_PGA='C:\Users\albertis\Downloads\CLATSKANIE\Raster\Singles_PGA_84';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct   
elseif  PGA=="8.7" && type=="clatskanie"
myDir_PGA='C:\Users\albertis\Downloads\CLATSKANIE\Raster\Singles_PGA_87';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct   
elseif  PGA=="9.0" && type=="clatskanie"
myDir_PGA='C:\Users\albertis\Downloads\CLATSKANIE\Raster\Singles_PGA_90';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct  
elseif PGA=="savePGA" && type=="clatskanie"
myDir_PGA='C:\Users\albertis\Downloads\CLATSKANIE\Raster\Singles_PGA_90';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct  
end

%% ELK
if PGA=="8.1" && type=="elk"
myDir_PGA='C:\Users\albertis\Downloads\ELK\Raster\Singles_PGA_81';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct   
elseif  PGA=="8.4" && type=="elk"
myDir_PGA='C:\Users\albertis\Downloads\ELK\Raster\Singles_PGA_84';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct   
elseif  PGA=="8.7" && type=="elk"
myDir_PGA='C:\Users\albertis\Downloads\ELK\Raster\Singles_PGA_87';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct   
elseif  PGA=="9.0" && type=="elk"
myDir_PGA='C:\Users\albertis\Downloads\ELK\Raster\Singles_PGA_90';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct 
elseif PGA=="savePGA" && type=="elk"
myDir_PGA='C:\Users\albertis\Downloads\ELK\Raster\Singles_PGA_90';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct  
end

%% NORTH COAST
if PGA=="8.1" && type=="north_coast"
myDir_PGA='C:\Users\albertis\Downloads\NORTHERN_COAST\Raster\Singles_PGA_81';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct   
elseif  PGA=="8.4" && type=="north_coast"
myDir_PGA='C:\Users\albertis\Downloads\NORTHERN_COAST\Raster\Singles_PGA_84';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct   
elseif  PGA=="8.7" && type=="north_coast"
myDir_PGA='C:\Users\albertis\Downloads\NORTHERN_COAST\Raster\Singles_PGA_87';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct   
elseif  PGA=="9.0" && type=="north_coast"
myDir_PGA='C:\Users\albertis\Downloads\NORTHERN_COAST\Raster\Singles_PGA_90';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct  
elseif PGA=="savePGA" && type=="north_coast"
myDir_PGA='C:\Users\albertis\Downloads\NORTHERN_COAST\Raster\Singles_PGA_90';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct  
end

%% SOUTH COAST
if PGA=="8.1" && type=="south_coast"
myDir_PGA='C:\Users\albertis\Downloads\SOUTHERN_COAST\Raster\Singles_PGA_81';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct   
elseif  PGA=="8.4" && type=="south_coast"
myDir_PGA='C:\Users\albertis\Downloads\SOUTHERN_COAST\Raster\Singles_PGA_84';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct   
elseif  PGA=="8.7" && type=="south_coast"
myDir_PGA='C:\Users\albertis\Downloads\SOUTHERN_COAST\Raster\Singles_PGA_87';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct   
elseif  PGA=="9.0" && type=="south_coast"
myDir_PGA='C:\Users\albertis\Downloads\SOUTHERN_COAST\Raster\Singles_PGA_90';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct  
elseif PGA=="savePGA" && type=="south_coast"
myDir_PGA='C:\Users\albertis\Downloads\SOUTHERN_COAST\Raster\Singles_PGA_90';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct  
end

%% EUGENE
if PGA=="8.1" && type=="eugene"
myDir_PGA='C:\Users\albertis\Downloads\EUGENE\Raster\Singles_PGA_81';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct   
elseif  PGA=="8.4" && type=="eugene"
myDir_PGA='C:\Users\albertis\Downloads\EUGENE\Raster\Singles_PGA_84';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct   
elseif  PGA=="8.7" && type=="eugene"
myDir_PGA='C:\Users\albertis\Downloads\EUGENE\Raster\Singles_PGA_87';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct   
elseif  PGA=="9.0" && type=="eugene"
myDir_PGA='C:\Users\albertis\Downloads\EUGENE\Raster\Singles_PGA_90';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct  
elseif PGA=="savePGA" && type=="eugene"
myDir_PGA='C:\Users\albertis\Downloads\EUGENE\Raster\Singles_PGA_90';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct 
end

%% SALEM
if PGA=="8.1" && type=="salem"
myDir_PGA='C:\Users\albertis\Downloads\SALEM\Raster\Singles_PGA_81';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct   
elseif  PGA=="8.4" && type=="salem"
myDir_PGA='C:\Users\albertis\Downloads\SALEM\Raster\Singles_PGA_84';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct   
elseif  PGA=="8.7" && type=="salem"
myDir_PGA='C:\Users\albertis\Downloads\SALEM\Raster\Singles_PGA_87';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct   
elseif  PGA=="9.0" && type=="salem"
myDir_PGA='C:\Users\albertis\Downloads\SALEM\Raster\Singles_PGA_90';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct  
elseif PGA=="savePGA" && type=="salem"
myDir_PGA='C:\Users\albertis\Downloads\SALEM\Raster\Singles_PGA_90';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struc
end

%% VERNONIA
if PGA=="8.1" && type=="vernonia"
myDir_PGA='C:\Users\albertis\Downloads\VERNONIA\Raster\Singles_PGA_81';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct   
elseif  PGA=="8.4" && type=="vernonia"
myDir_PGA='C:\Users\albertis\Downloads\VERNONIA\Raster\Singles_PGA_84';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct   
elseif  PGA=="8.7" && type=="vernonia"
myDir_PGA='C:\Users\albertis\Downloads\VERNONIA\Raster\Singles_PGA_87';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct   
elseif  PGA=="9.0" && type=="vernonia"
myDir_PGA='C:\Users\albertis\Downloads\VERNONIA\Raster\Singles_PGA_90';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct 
elseif PGA=="savePGA" && type=="vernonia"
myDir_PGA='C:\Users\albertis\Downloads\VERNONIA\Raster\Singles_PGA_90';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struc
end

%% GALES
if PGA=="8.1" && type=="gales"
myDir_PGA='C:\Users\albertis\Downloads\GALES\Raster\Singles_PGA_81';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct   
elseif  PGA=="8.4" && type=="gales"
myDir_PGA='C:\Users\albertis\Downloads\GALES\Raster\Singles_PGA_84';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct   
elseif  PGA=="8.7" && type=="gales"
myDir_PGA='C:\Users\albertis\Downloads\GALES\Raster\Singles_PGA_87';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct   
elseif  PGA=="9.0" && type=="gales"
myDir_PGA='C:\Users\albertis\Downloads\GALES\Raster\Singles_PGA_90';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct
elseif PGA=="savePGA" && type=="gales"
myDir_PGA='C:\Users\albertis\Downloads\GALES\Raster\Singles_PGA_90';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struc
end

%% SCOTTSBURG
if PGA=="8.1" && type=="scottsburg"
myDir_PGA='C:\Users\albertis\Downloads\SCOTTSBURG\Raster\Singles_PGA_81';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct   
elseif  PGA=="8.4" && type=="scottsburg"
myDir_PGA='C:\Users\albertis\Downloads\SCOTTSBURG\Raster\Singles_PGA_84';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct   
elseif  PGA=="8.7" && type=="scottsburg"
myDir_PGA='C:\Users\albertis\Downloads\SCOTTSBURG\Raster\Singles_PGA_87';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct   
elseif  PGA=="9.0" && type=="scottsburg"
myDir_PGA='C:\Users\albertis\Downloads\SCOTTSBURG\Raster\Singles_PGA_90';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct
elseif PGA=="savePGA" && type=="scottsburg"
myDir_PGA='C:\Users\albertis\Downloads\SCOTTSBURG\Raster\Singles_PGA_90';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct
end

%% FLORENCE
if PGA=="8.1" && type=="florence"
myDir_PGA='C:\Users\albertis\Downloads\FLORENCE\Raster\Singles_PGA_81';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct   
elseif  PGA=="8.4" && type=="florence"
myDir_PGA='C:\Users\albertis\Downloads\FLORENCE\Raster\Singles_PGA_84';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct   
elseif  PGA=="8.7" && type=="florence"
myDir_PGA='C:\Users\albertis\Downloads\FLORENCE\Raster\Singles_PGA_87';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct   
elseif  PGA=="9.0" && type=="florence"
myDir_PGA='C:\Users\albertis\Downloads\FLORENCE\Raster\Singles_PGA_90';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct  
elseif PGA=="savePGA" && type=="florence"
myDir_PGA='C:\Users\albertis\Downloads\FLORENCE\Raster\Singles_PGA_90';
myFiles_PGA = dir(fullfile(myDir_PGA,'*.tif')); %gets all wav files in struct
end

end
