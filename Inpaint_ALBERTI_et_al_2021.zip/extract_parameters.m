
function [relief,area_sh,volume_sh,AR,Aspect_avg,Slope_avg,Elevation_avg,Max_thick,Thick_avg,Median_Thick,SD_Thick,reg_prop,litho,mov_class,AR_rg,zss_e,zsurf_e,length,max_length,max_length_rg,Slope_ss_avg] ...
    = extract_parameters(Z_arizona,Zss,mask_bool_double,roi,Aspect,Slope,Slope_ss,type,cellsize,X,Y,Z_inp)

%% convert cell to string
type=string(type);

%% conversion rate
c_rate_m_2=0.092903; % ft^2 to m^2
c_rate_m=0.3048; % feet to m

%% Find relief % meters
%Z_arizona_bool=Z_arizona.*mask_bool_double;
Z_arizona_max=max(Z_arizona(mask_bool_double==1));
Z_arizona_min=min(Z_arizona(mask_bool_double==1));
relief=Z_arizona_max-Z_arizona_min;
relief=max(relief);
relief=relief.*c_rate_m;

%% Area %meters
area_sh=roi.Shape_Area;
%area=roi.Area;
area_sh=area_sh.*c_rate_m_2; % m^2

%% Volume % meters
deep_avg=(Z_arizona-Zss).*mask_bool_double; % feet
%deep_avg(deep_avg==0)=NaN; % feet
deep_avg(deep_avg<=0)=NaN; % feet % run with Ben on 05/22/2021
deep_avg=mean(deep_avg,'all','omitnan'); % feet
%deep_avg=mean(deep_avg,'omitnan'); % feet
deep_avg=deep_avg.*c_rate_m; % feet to m
volume_sh=area_sh.*deep_avg; % m^3

%% Aspect Ratio
X_ar=(abs(roi.BoundingBox(1,1)-roi.BoundingBox(2,1))).*c_rate_m;
Y_ar=(abs(roi.BoundingBox(1,2)-roi.BoundingBox(2,2))).*c_rate_m;
AR=X_ar/Y_ar;

if X_ar>Y_ar
max_length=X_ar;
elseif X_ar<Y_ar
max_length=Y_ar;
end


%% AVG Aspect
Aspect_avg=Aspect.*mask_bool_double;
Aspect_avg(Aspect_avg==0)=NaN; 
Aspect_avg=mean(Aspect_avg,'all','omitnan'); 

%% AVG Slope
Slope_avg=Slope.*mask_bool_double; 
Slope_avg(Slope_avg==0)=NaN; 
Slope_avg=mean(Slope_avg,'all','omitnan');

%% AVG Slip Surface
Slope_ss_avg=Slope_ss.*mask_bool_double; 
Slope_ss_avg(Slope_ss_avg==0)=NaN; 
Slope_ss_avg=mean(Slope_ss_avg,'all','omitnan');

%% Roughness
%type='tri' % Riley et al. 1999 (ArcMap)
%Tool boox [OUT] = roughness(DEM,type,ks)

%% Mean elevation
Elevation_avg=Z_arizona.*mask_bool_double;
Elevation_avg=mean(nonzeros(Elevation_avg),'all','omitnan'); % feet
Elevation_avg=Elevation_avg.*c_rate_m; % meters

%% Max and Mean, Median and SD of Thickness
thickness=Z_arizona-Zss; thickness(thickness<=0)=NaN;% feet
thickness=thickness.*mask_bool_double; % feet
thickness_m=thickness*c_rate_m; % meters
Max_thick=max(thickness_m,[],'omitnan'); % feet
Max_thick=(max(Max_thick)); % meters
Thick_avg=(mean(nonzeros(thickness_m),'all','omitnan')); % feet
Median_Thick=(median(nonzeros(thickness_m),'all','omitnan')); % feet
SD_Thick=std(thickness_m,1,'all','omitnan'); %meters 
%SD_Thick=mean(nonzeros(SD_Thick),'all','omitnan'); % feet

%% Region properties
reg_prop=regionprops(mask_bool_double,'Area','BoundingBox','Circularity','Eccentricity','Orientation','Perimeter','MajorAxisLength','MinorAxisLength','Centroid');

for i=1
if reg_prop.Orientation < 0 
AR_rg=(reg_prop.MajorAxisLength./reg_prop.MinorAxisLength); 
max_length_rg=reg_prop.MajorAxisLength.*(20./3.28);
else %if  reg_pro.Orientation > 0 
AR_rg=(reg_prop.MinorAxisLength./reg_prop.MajorAxisLength);
max_length_rg=reg_prop.MajorAxisLength.*(20./3.28);
end
end

% Profiles
% imagesc(mask_bool_double); hold on
% scatter(reg_prop.Centroid(1),reg_prop.Centroid(2))
% xmajor=linspace(reg_prop.Centroid(1)-reg_prop.BoundingBox(3)/2,reg_prop.Centroid(1)+reg_prop.BoundingBox(3)/2,10);
% ymajor=(xmajor-min(xmajor)).*-sind(reg_prop.Orientation)+reg_prop.Centroid(2)-reg_prop.BoundingBox(4)/2;
buffer=5;
xmajor1=linspace(reg_prop.Centroid(1)-reg_prop.BoundingBox(3)/2-buffer,reg_prop.Centroid(1),20);
xmajor2=linspace(reg_prop.Centroid(1),reg_prop.Centroid(1)+reg_prop.BoundingBox(3)/2+buffer,20);
ymajor1=(xmajor1-max(xmajor1)).*-sind(reg_prop.Orientation)+reg_prop.Centroid(2);
ymajor2=(xmajor2-min(xmajor2)).*-sind(reg_prop.Orientation)+reg_prop.Centroid(2);
xmajor=horzcat(xmajor1,xmajor2);
ymajor=horzcat(ymajor1,ymajor2);
% plot(xmajor,ymajor);
xmajor=xmajor.*cellsize;
ymajor=ymajor.*cellsize;
%rectangle('position',reg_prop.BoundingBox,'Edgecolor','g')
length=sqrt((xmajor-xmajor(1)).^2 + (ymajor-ymajor(1)).^2);

zsurf_e=interp2(X,Y,Z_inp,xmajor+min(X,[],'all'),ymajor+min(Y,[],'all'));
zss_e=interp2(X,Y,Zss,xmajor+min(X,[],'all'),ymajor+min(Y,[],'all'));

% figure;
% plot(length,zsurf_e,'k'); hold on
% plot(length,zss_e,'r')
% axis equal

%% Lithology and Move class
% if type='bluff' || type='bluff_total'
% litho='empty';
% mov_class='empty';  

if type=='coastal'
litho='empty'; % roi.MapUnitNam; %roi.GEOL;
mov_class=roi.MOVE_CLASS; 
else 
litho=roi.ThematicLi; % roi.MapUnitNam; %roi.GEOL;
mov_class=roi.MOVE_CLASS;


end