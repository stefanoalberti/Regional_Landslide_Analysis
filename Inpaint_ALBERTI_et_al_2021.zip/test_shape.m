
%%%%%%%%%%%%%%%%%
%%% shapefile %%%
%%%%%%%%%%%%%%%%%

% Name_file='C:\Users\albertis\Downloads\Geodatabase\merge_all_landslid.shp';
% shapeinfo(Name_file)
% S_or=shaperead(Name_file,'Selector',{@TYPE_MOVE, TYPE_MOVE ~= Complex, 'CLASS'});
% %X=S.X;
% 
% % geom='Polygon'
% % BB=S_or(1).BoundingBox;
% % X=S_or(1).X;
% % Y=S_or(1).Y;
% % 
% % S=struct('Geometry',geom,'BoundingBox',BB,'X',X,'Y',Y);
% shapewrite(S_or,'test.shp');

%% Extract data for join in ArcGIS
% output_sat0_tosave=[output_sat0.c_max,output_sat0.phi_max,output_sat0.Relief,output_sat0.Area_sh,output_sat0.Area,output_sat0.Volume_sh,output_sat0.Volume,...
%     output_sat0.AR,output_sat0.AR_rg,output_sat0.AspectAVG,output_sat0.SlopeAVG,output_sat0.SlopeSsAVG,output_sat0.Rot,output_sat0.ElevationAVG,output_sat0.MaxThickness,...
%     output_sat0.MeanThickness,output_sat0.MedianThickness,output_sat0.SDThickness,output_sat0.VolumeAreaRatio,output_sat0.max_length,output_sat0.max_length_rg,...
%     output_sat0.PGA,output_sat0.rain];
% 
% output_sat0_tosave_string=[output_sat0.name,output_sat0.MoveClass,output_sat0.Lithology];

T=table(output_sat0.name,output_sat0.MoveClass,output_sat0.Lithology,output_sat0.c_max,output_sat0.phi_max,output_sat0.Relief,output_sat0.Area_sh,output_sat0.Area,output_sat0.Volume_sh,output_sat0.Volume,...
    output_sat0.AR,output_sat0.AR_rg,output_sat0.AspectAVG,output_sat0.SlopeAVG,output_sat0.SlopeSsAVG,output_sat0.Rot,output_sat0.ElevationAVG,output_sat0.MaxThickness,...
    output_sat0.MeanThickness,output_sat0.MedianThickness,output_sat0.SDThickness,output_sat0.VolumeAreaRatio,output_sat0.max_length,output_sat0.max_length_rg,...
    output_sat0.PGA,output_sat0.rain);

T.Properties.VariableNames = {'UniqueID' 'MoveClass' 'Lithology' 'C_max' 'Phi_max' 'Relief' 'Area_sh' 'Area' 'Volume_sh' 'Volume' 'AR'...
    'AR_rg' 'AspectAVG' 'SlopeAVG' 'SlopeSsAVG' 'Rot' 'ElevationAVG' 'MaxThickness' 'MeanThickness' 'MedianThickness' 'SDThickness' 'VolumeAreaRatio'...
    'max_length' 'max_length_rg' 'PGA' 'rain'};

writetable(T,'vernonia.txt');