function[R_arizona,Z_arizona,Zss,Rss,x_cellsize_arizona,y_cellsize_arizona,nx_arizona,ny_arizona,Xarizona,Yarizona,Z_PGA,Z_rain]=process_DEM(fullFileName_ss,fullFileName_dem,PGA,fullFileName_rain,fullFileName_PGA);
%[R_arizona,Z_arizona,Slope,Aspect,Slope_ss,Aspect_ss,dx,dy,Zss,Rss,x_cellsize_arizona,y_cellsize_arizona,nx_arizona,ny_arizona,Xarizona,Yarizona]=process_DEM(fullFileName_ss,fullFileName_dem)
% -------------------------------------------------------------------------------------------------
% description: import data from geotiff files about x, y, z, georeference,
% # columns, # rows, cellsize, aspect, slope
% -------------------------------------------------------------------------------------------------
% input variables
% //
% % output variables
% - R_arizona:              georefence data of imported DEM           
% - Z_arizona:              z value (altitude) of imported DEM
% - Slope:                  slope of imported DEM (using gradient_king function)
% - Aspect:                 aspect of imported DEM (using gradient_king function)
% - Slope_ss:               slope of slip surface DEM (using gradient_king function)
% - Aspect_ss:              aspect of slip surface DEM (using gradient_king function)
% - dx:
% - dy:
% - Zss:                    z value (altitude) of slip surface DEM
% - Rss:                    georefence data of slip surface DEM
% - x_cellsize_arizona:     cell size (calculate one time because same size)
% - y_cellsize_arizona:     cell size     
% - nx_arizona:             # rows (calculate one time because same size)
% - ny_arizona:             # columns 
% - Xarizona:
% - Yarizona:
% -------------------------------------------------------------------------------------------------

%clear all

[Z_arizona,R_arizona]= readgeoraster(fullFileName_dem,'OutputType','double');
    save Elevation_Raster Z_arizona;
    save Georeference R_arizona;
    
    % Synthetic slope
    % C:\Users\albertis\Desktop\Synthetic Slopes\Raster\test_synt_slope.tif
    
    % Arizona 
    % C:\Users\albertis\Desktop\Data4Matlab\Input Files\Arizona\dem_20feet_arizona_UTM.tif
    
    % Johnson 
    %C:\Users\albertis\Desktop\Data4Matlab\Input Files\Johnson Creek\be44124f4_cut_20feet.tif
    
    % Carmel Knoll
    % C:\Users\albertis\Desktop\Data4Matlab\Carmel Knoll\Carmel_20200807\ProjDEM.tif


% %[Z2018,R2018]=readgeoraster('C:\Users\albertis\Desktop\CMmatlab\Mod\fd_solver\2018_DEM_3m_area.tif');
%     save Elevation_Raster Z2018
%     save Georeference R2018
%     
[Zss,Rss]=readgeoraster(fullFileName_ss);
    save Elevation_Raster Zss
    save Georeference Rss
    
[Z_rain,R_rain]=readgeoraster(fullFileName_rain);
    save Elevation_Raster Z_rain
    save Georeference R_rain

 %if PGA~="0" 
[Z_PGA,R_PGA]=readgeoraster(fullFileName_PGA);
    save Elevation_Raster Z_PGA
    save Georeference R_PGA
 %end     
    % Synthetic slope
    % C:\Users\albertis\Desktop\Synthetic Slopes\Raster\test_synt_slip_surf.tif
    
    % Arizona 
    % C:\Users\albertis\Desktop\Data4Matlab\Input Files\Arizona\slip_surf.tif
    
    % Johnson 
    % C:\Users\albertis\Desktop\Data4Matlab\Johnson\johnson_RP_20200707_simplified\Rupture_Surfaces\slip_surf.tif    
    
    % Carmel Knoll
    % C:\Users\albertis\Desktop\Data4Matlab\Carmel Knoll\Carmel_RS_20200707_simplified\Rupture_Surfaces\slip_surf.tif
%        
% %[Zss_upper_deep,Rss_upper_deep]=readgeoraster('C:\Users\albertis\Desktop\CMmatlab\Mod\fd_solver\slip_surface_mask_upper_v2.tif');
%     save Elevation_Raster Zss_upper_deep
%     save Georeference Rss_upper_deep
% 
% %[Zss_upper_shallow,Rss_upper_shallow]=readgeoraster('C:\Users\albertis\Desktop\CMmatlab\Mod\fd_solver\slip_surface_mask_upper_v1.tif');
%     save Elevation_Raster Zss_upper_shallow
%     save Georeference Rss_upper_shallow    
%     
% %[Zbool_central,Rbool_central]=readgeoraster('C:\Users\albertis\Desktop\CMmatlab\Mod\fd_solver\mask_0_1_2.tif');
%     save Elevation_Raster Zbool_central
%     save Georeference Rbool_central
% 
% %[Zbool_upper_deep,Rbool_upper_deep]=readgeoraster('C:\Users\albertis\Desktop\CMmatlab\Mod\fd_solver\mask_0_2.tif');
%     save Elevation_Raster Zbool_upper_deep
%     save Georeference Rbool_upper_deep   
%     
% %[Zbool_upper_shallow,Rbool_upper_shallow]=readgeoraster('C:\Users\albertis\Desktop\CMmatlab\Mod\fd_solver\mask_0_2_v1.tif');
%     save Elevation_Raster Zbool_upper_shallow
%     save Georeference Rbool_upper_shallow 
       
%% Create x and y references to each cell of the DEM %-%-%-%-%-%-%-%-%-%-%-
%DEM Data
x_cellsize_arizona = R_arizona.CellExtentInWorldX;
y_cellsize_arizona = R_arizona.CellExtentInWorldY;
[m_arizona,n_arizona] = size(Z_arizona); % m rows (x-dir), and n cols (y-dir)
nx_arizona = size(Z_arizona,1); % number of rows
ny_arizona = size(Z_arizona,2); % number of cols
Xarizona = repmat((x_cellsize_arizona:x_cellsize_arizona:m_arizona*x_cellsize_arizona)',1,n_arizona);
Yarizona = repmat((y_cellsize_arizona:y_cellsize_arizona:n_arizona*y_cellsize_arizona),m_arizona,1);
Z_arizona(Z_arizona>2000 | Z_arizona<-100)=NaN; %original 
%Z_arizona(Z_arizona>1000 | Z_arizona<-1000)=0; % added by Stefano 02/05/2021
% Compute Slope and Aspect for the base of the soil columns
%[Slope,Aspect,dx,dy] = gradient_king(Z_arizona,R_arizona);

%Slip Surface Data
x_cellsize_ss = Rss.CellExtentInWorldX;
y_cellsize_ss = Rss.CellExtentInWorldY;
[m_ss,n_ss] = size(Zss); % m rows (x-dir), and n cols (y-dir)
nx_ss = size(Zss,1); % number of rows
ny_ss = size(Zss,2); % number of cols
Xss = repmat((x_cellsize_ss:x_cellsize_ss:m_ss*x_cellsize_ss)',1,n_ss);
Yss = repmat((y_cellsize_ss:y_cellsize_ss:n_ss*y_cellsize_ss),m_ss,1);
Zss(Zss>2000 | Zss<-100)=NaN;
% Compute Slope and Aspect for the base of the soil columns
%[Slope_ss,Aspect_ss,dx_ss,dy_ss] = gradient_king(Zss,Rss);

%% Rain
Z_rain(Z_rain<=0)=NaN;

%% PGA
if PGA~="0" 
Z_PGA(Z_PGA<=0)=NaN;
else
    Z_PGA=0;
end

% %2018 Data
% x_cellsize_2018 = R2018.CellExtentInWorldX;
% y_cellsize_2018 = R2018.CellExtentInWorldY;
% [m2018,n2018] = size(Z2018); % m rows (x-dir), and n cols (y-dir)
% nx2018 = size(Z2018,1); % number of rows
% ny2018 = size(Z2018,2); % number of cols
% X2018 = repmat((x_cellsize_2018:x_cellsize_2018:m2018*x_cellsize_2018)',1,n2018);
% Y2018 = repmat((y_cellsize_2018:y_cellsize_2018:n2018*y_cellsize_2018),m2018,1);
% Z2018(Z2018>1000 | Z2018<-1000)=NaN;
% % Compute Slope and Aspect for the base of the soil columns
% [Slope2018,Aspect2018,dx2018,dy2018] = gradient_king(Z2018,R2018);

% %Central Slip Surface Data
% x_cellsize_central = Rss_central.CellExtentInWorldX;
% y_cellsize_central = Rss_central.CellExtentInWorldY;
% [m_central,n_central] = size(Zss_central); % m rows (x-dir), and n cols (y-dir)
% nx_central = size(Zss_central,1); % number of rows
% ny_central = size(Zss_central,2); % number of cols
% Xss_central = repmat((x_cellsize_central:x_cellsize_central:m_central*x_cellsize_central)',1,n_central);
% Yss_central = repmat((y_cellsize_central:y_cellsize_central:n_central*y_cellsize_central),m_central,1);
% Zss_central(Zss_central>1000 | Zss_central<-1000)=NaN;
% Zss_central(Zss_central==0)=Z2012(Zss_central==0);
% % Compute Slope and Aspect for the base of the soil columns
% [Slope_central,Aspect_central,dx_central,dy_central] = gradient_king(Zss_central,Rss_central);
% 
% %Upper Deep Slip Surface Data
% x_cellsize_upper_deep = Rss_upper_deep.CellExtentInWorldX;
% y_cellsize_upper_deep = Rss_upper_deep.CellExtentInWorldY;
% [m_upper_deep,n_upper_deep] = size(Zss_upper_deep); % m rows (x-dir), and n cols (y-dir)
% nx_upper_deep = size(Zss_upper_deep,1); % number of rows
% ny_upper_deep = size(Zss_upper_deep,2); % number of cols
% Xss_upper_deep = repmat((x_cellsize_upper_deep:x_cellsize_upper_deep:m_upper_deep*x_cellsize_upper_deep)',1,n_upper_deep);
% Yss_upper_deep = repmat((y_cellsize_upper_deep:y_cellsize_upper_deep:n_upper_deep*y_cellsize_upper_deep),m_upper_deep,1);
% Zss_upper_deep(Zss_upper_deep>1000 | Zss_upper_deep<-1000)=NaN;
% Zss_upper_deep(Zss_upper_deep==0)=Z2012(Zss_upper_deep==0);
% % Compute Slope and Aspect for the base of the soil columns
% [Slope_upper_deep,Aspect_upper_deep,dx_upper_deep,dy_upper_deep] = gradient_king(Zss_upper_deep,Rss_upper_deep);
% 
% %Upper Shallow Slip Surface Data
% x_cellsize_upper_shallow = Rss_upper_deep.CellExtentInWorldX;
% y_cellsize_upper_shallow = Rss_upper_deep.CellExtentInWorldY;
% [m_upper_shallow,n_upper_shallow] = size(Zss_upper_deep); % m rows (x-dir), and n cols (y-dir)
% nx_upper_shallow = size(Zss_upper_deep,1); % number of rows
% ny_upper_shallow = size(Zss_upper_deep,2); % number of cols
% Xss_upper_shallow = repmat((x_cellsize_upper_shallow:x_cellsize_upper_shallow:m_upper_shallow*x_cellsize_upper_shallow)',1,n_upper_shallow);
% Yss_upper_shallow = repmat((y_cellsize_upper_shallow:y_cellsize_upper_shallow:n_upper_shallow*y_cellsize_upper_shallow),m_upper_shallow,1);
% Zss_upper_shallow(Zss_upper_shallow>1000 | Zss_upper_shallow<-1000)=NaN;
% Zss_upper_shallow(Zss_upper_shallow==0)=Z2012(Zss_upper_shallow==0);
% % Compute Slope and Aspect for the base of the soil columns
% [Slope_upper_shallow,Aspect_upper_shallow,dx_upper_shallow,dy_upper_shallow] = gradient_king(Zss_upper_shallow,Rss_upper_shallow);


% %Get Cell Size
% dx=x_cellsize_2012;
% dy=dx;
% 
% %Differenced DEMs
% % Zdiff=Z2018-Z2012;
% % Zdepth2018_upper_deep=Z2018-Zss_upper_deep;
% % Zdepth2012_upper_deep=Z2012-Zss_upper_deep;
% % Zdepth2018_upper_shallow=Z2018-Zss_upper_shallow;
% % Zdepth2012_upper_shallow=Z2012-Zss_upper_shallow;
% % Zdepth2018_central=Z2018-Zss_central;
% % Zdepth2012_central=Z2012-Zss_central;
% 
% Zbool_central(Zbool_central==2)=0;
% 
% %Zss_central(Zss_central<250)=250;
% 
% %Truncate Slip Surface Data
% Zss_central(Zss_central>Z2018 | Zss_central==0)=NaN;
% Zss_upper_deep(Zss_upper_deep>Z2018 | Zss_upper_deep==0)=NaN;
% Zss_upper_shallow(Zss_upper_shallow>Z2018 | Zss_upper_shallow==0)=NaN;
% 
% 
% %%smooth slip surfaces
% for k=1:1:200 
%     
% Zss_central=0.9999*movmean(Zss_central,3,1,'omitnan');
% Zss_central=0.9999*movmean(Zss_central,3,2,'omitnan');
% Zss_central(find(Zbool_central==0))=Z2012(find(Zbool_central==0));
% 
% Zss_upper_shallow=0.9999*movmean(Zss_upper_shallow,3,1,'omitnan');
% Zss_upper_shallow=0.9999*movmean(Zss_upper_shallow,3,2,'omitnan');
% Zss_upper_shallow(find(Zbool_upper_shallow==0))=Z2012(find(Zbool_upper_shallow==0));    
%     
% Zss_upper_deep=0.9999*movmean(Zss_upper_deep,3,1,'omitnan');
% Zss_upper_deep=0.9999*movmean(Zss_upper_deep,3,2,'omitnan');
% Zss_upper_deep(find(Zbool_upper_deep==0))=Z2012(find(Zbool_upper_deep==0));
% 
% end
% 
% 
% 
% %Finalize Failure Surfaces and Assign Small Thicknesses outside of surface
% Zss_central(isnan(Zss_central))=Z2012(isnan(Zss_central));
% Zss_central(Zbool_central==0)=Z2018(Zbool_central==0)-0.001;
% Zss_central(Zss_central>Z2012)=Z2012(Zss_central>Z2012)-0.001;
% Zss_central(Zss_central>Z2018)=Z2018(Zss_central>Z2018)-0.001;
% 
% Zss_upper_shallow(isnan(Zss_upper_shallow))=Z2012(isnan(Zss_upper_shallow));
% Zss_upper_shallow(Zbool_upper_shallow==0)=Z2018(Zbool_upper_shallow==0)-0.001;
% Zss_upper_shallow(Zss_upper_shallow>Z2012)=Z2012(Zss_upper_shallow>Z2012)-0.001;
% Zss_upper_shallow(Zss_upper_shallow>Z2018)=Z2018(Zss_upper_shallow>Z2018)-0.001;
% 
% 
% Zss_upper_deep(isnan(Zss_upper_deep))=Z2012(isnan(Zss_upper_deep));
% Zss_upper_deep(Zbool_upper_deep==0)=Z2018(Zbool_upper_deep==0)-0.001;
% Zss_upper_deep(Zss_upper_deep>Z2012)=Z2012(Zss_upper_deep>Z2012)-0.001;
% Zss_upper_deep(Zss_upper_deep>Z2018)=Z2018(Zss_upper_deep>Z2018)-0.001;
% 
% %Assign Booleans IDs (1=central block, 2=upper shallow, 3=upper_deep)
% Zbool_central(Zbool_central~=1)=0;
% Zbool_upper_shallow(Zbool_upper_shallow~=2)=0;
% Zbool_upper_deep(Zbool_upper_deep~=2)=0;
% Zbool_upper_deep(Zbool_upper_deep==2)=3;
% 
% %Boundary Conditions for Booleans
% Zbool_central=double(Zbool_central);
% Zbool_central(1:2,:)=0;
% Zbool_central(:,1:2)=0;
% Zbool_central(end-1:end,:)=0;
% Zbool_central(:,end-1:end)=0;
% 
% Zbool_upper_shallow=double(Zbool_upper_shallow);
% Zbool_upper_shallow(1:2,:)=0;
% Zbool_upper_shallow(:,1:2)=0;
% Zbool_upper_shallow(end-1:end,:)=0;
% Zbool_upper_shallow(:,end-1:end)=0;
% 
% Zbool_upper_deep=double(Zbool_upper_deep);
% Zbool_upper_deep(1:2,:)=0;
% Zbool_upper_deep(:,1:2)=0;
% Zbool_upper_deep(end-1:end,:)=0;
% Zbool_upper_deep(:,end-1:end)=0;
% 
% 
% 
% 
% Zdiff=double(Zdiff);
% Zdiff_central=Zdiff.*Zbool_central;
% Zdiff_upper_shallow=Zdiff.*Zbool_upper_shallow;
% Zdiff_upper_deep=Zdiff.*Zbool_upper_deep;
% h_central=double(Zdepth2012_central.*Zbool_central);
% h_upper_shallow=double(Zdepth2012_upper_shallow.*Zbool_upper_shallow);
% h_upper_deep=double(Zdepth2012_upper_deep.*Zbool_upper_deep);

end