
function [Z_inp] = f_inpait(method,fullFileName,Z_arizona,fullFileName_dem)

method = 4; 

% Create Boolean mask    
DEM_area = fullFileName_dem;
R = geotiffinfo(DEM_area);
[x,y] = pixcenters(R); 
% Convert x,y arrays to grid - region of interest : sempre de
[X,Y] = meshgrid(x,y);
roi = shaperead(fullFileName);
% Remove trailing nan from shapefile
rx = roi.X(1:end-1);
ry = roi.Y(1:end-1);
% boolean mask
mask_bool_logical = inpolygon(X,Y,rx,ry); % generate boolean values to indicate in/outside landslide

% Prepare DEM 
Z_arizona(isnan(Z_arizona))=0; % replace NaN values with 0
Ztemp=Z_arizona.*mask_bool_logical;
Ztemp(Ztemp>0)=NaN;
Ztemp(Ztemp==0)=1;
Ztemp=Ztemp.*Z_arizona;

% do inpainting 
[Z_inp]=inpaint_nans(Ztemp,method);

end

