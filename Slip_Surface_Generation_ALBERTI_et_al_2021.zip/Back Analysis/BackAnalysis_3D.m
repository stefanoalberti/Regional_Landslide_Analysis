clear all;
%% Version 4: Regional Analysis
tic
% A) Compute dx, dy for all angles 0 to 360 (Only makes sense for large datasets);
% B) Perform iteration only on mask-sized DEM

%% 1. Specify model inputs
phi_thresh = 35;
c_thresh = 0;
gw = 62.4;  % Unit weight of water, lb/ft3
gd = 114.5;
gs = 133.6;   % Unit weight of moist soil, lb/ft3

gi = (gd+gs)/2;
ru_i = 0.25;% Ru value for custom input (i)

ky = 0.00;  % Pseudo-static coeff for EQ. in longitudinal
kx = 0;     % Pseudo-static coeff for EQ. in transverse
Ey = 0;     % Applied horizontal load in longitudinal
Ex = 0;     % Applied horizontal load in transverse

%% Read input data
% Get substudy location
% path = 'F:\Strength_Manuscript\Substudies\AZI_40';% Application
% path2 = 'F:\Strength_Manuscript\Substudies\AZI_40';% Parameter Source
path = 'F:\Strength_Manuscript\Substudies\Ophir';% Application% <---------<<<<

% Read landslide extents (use attributes.shp for aspect)
[~,study] = fileparts(path);
dep_shp = fullfile(path,'Rupture_Surfaces','attributes.shp');% <---------<<<<CHANGE
F = shaperead(dep_shp);

% Name output extents
ba_shp = fullfile(path,'Rupture_Surfaces','back_analysis.shp');% <---------<<<<

% Read slip surface DEM
slip_surf = fullfile(path,'Rupture_Surfaces','slip_surf.tif');
[Slip,R] = geotiffread(slip_surf);
csize = R.CellExtentInWorldX;

% Read ground surfaces
top_surf = fullfile(path,'Rupture_Surfaces','top_surf2.tif');
[TOP,~] = geotiffread(top_surf); % for Catastrophic

dem_surf = fullfile(path,'ProjDEM.tif');
[DEM,~] = geotiffread(dem_surf); % for Progressive

% Compute slip surface slope
[SLOPE,ASPECT,DX,DY] = gradient_king(Slip,csize);


%% Prepare input data for analysis
% Prepare coordinates from DEM for indexing
geoinfo = geotiffinfo(dem_surf);
[x,y] = pixcenters(geoinfo);
[X,Y] = meshgrid(x,y);
clearvars x y

% Convert slope in x and y directions from rise/run to degrees
DX = atand(DX);
DY = atand(DY);

% Select Ru based on user settings
ru = ru_i;

%% Perform analysis on each landslide
omit = 0;
% Loop through all features in F (extent shapefile)
for idx = 1:length(F)
    % Get binary index (mask) for current landslide and XY limits
    mask = create_shp_mask(F,idx,geoinfo);
    xmask = X<(max(X(mask))+50) & X>(min(X(mask))-50);
    ymask = Y<(max(Y(mask))+50) & Y>(min(Y(mask))-50);
    XY_mask = xmask==1 & ymask == 1;
    
    [XYr,XYc] = find(XY_mask==1);
    XYminr = min(XYr); XYmaxr = max(XYr);
    XYminc = min(XYc); XYmaxc = max(XYc);
    
    mask_red = mask(XYminr:XYmaxr,XYminc:XYmaxc);
    
    % Read attributes from F
    asp = F(idx).aspect;% Mean aspect of all surficial pixels
    fail_type = F(idx).FAIL_TYPE;% Fail type: 'Catastrophic' or 'Progressive'
    
    % Choose ground surface based on fail type and limit rasters to current
    % slide
    S = Slip(XY_mask);
    G = [];
    if strcmp(fail_type,'Progressive') == 1
        G = DEM(XY_mask);
    else
        G = TOP(XY_mask);
    end
    Slope = SLOPE(XY_mask);
    Aspect = ASPECT(XY_mask);
    Rgh = std(Slope);
    if isnan(Rgh)==1
        Rgh = 0;
    end
        
    
    % Compute weight of column
    W0 = (csize)*(csize).*(G-S);
    
    
    
    F(idx).g_d = double(gd);
    F(idx).g_s = double(gs);
    F(idx).g_w = double(gw);
    F(idx).g_i = double(gi);
    F(idx).Ru = double(ru);
    F(idx).Rgh = double(Rgh);
    
    % If landslide has no volume, do not perform back-analysis
    if sum(W0(mask_red))==0 || isnan(sum(W0(mask_red)))
        F(idx).Su_d = double(0);
        F(idx).rot_Su_d = double(0);
        F(idx).Su_s = double(0);
        F(idx).rot_Su_s = double(0);
        F(idx).phi_d = double(0);
        F(idx).rot_phi_d = double(0);
        F(idx).phi_s = double(0);
        F(idx).rot_phi_s = double(0);
        F(idx).phi_i = double(0);
        F(idx).rot_phi_i = double(0);
        F(idx).phi35 = double(0);
        F(idx).c35 = double(0);
        F(idx).rot35 = double(0);
        % ADD OTHER ATTRIBUTES (E, kx, etc) HERE

    else% Landslide does have volume

        % Get u from ru
        u_s = gw.*(G-S).*(gw/gs);
        u_i = gw.*(G-S).*ru;
        u_d = gw.*(G-S).*0;
        
        [rot, phif, cf] = SimpJanbu3D(mask_red, csize, Slope, Aspect, asp, c_thresh, phi_thresh, W0, u_s, gs, 'c', kx, ky, Ex, Ey);
        
        
        [rot_Su_d, ~, Su_d] = SimpJanbu3D(mask_red, csize, Slope, Aspect, asp,...
            0, 0, W0, u_d, gd, 'c', kx, ky, Ex, Ey);
        F(idx).Su_d = double(Su_d);
        F(idx).rot_Su_d = double(rot_Su_d);
        
        [rot_Su_s, ~, Su_s] = SimpJanbu3D(mask_red, csize, Slope, Aspect, asp,...
            0, 0, W0, u_s, gs, 'c', kx, ky, Ex, Ey);
        F(idx).Su_s = double(Su_s);
        F(idx).rot_Su_s = double(rot_Su_s);
        
        [rot_phi_d, phi_d, ~] = SimpJanbu3D(mask_red, csize, Slope, Aspect, asp,...
            0, 0, W0, u_d, gd, 'phi', kx, ky, Ex, Ey);
        F(idx).phi_d = double(phi_d);
        F(idx).rot_phi_d = double(rot_phi_d);
        
        [rot_phi_s, phi_s, ~] = SimpJanbu3D(mask_red, csize, Slope, Aspect, asp,...
            0, 0, W0, u_s, gs, 'phi', kx, ky, Ex, Ey);
        F(idx).phi_s = double(phi_s);
        F(idx).rot_phi_s = double(rot_phi_s);
        
        [rot_phi_i, phi_i, ~] = SimpJanbu3D(mask_red, csize, Slope, Aspect, asp,...
            0, 0, W0, u_i, gi, 'phi', kx, ky, Ex, Ey);
        F(idx).phi_i = double(phi_i);
        F(idx).rot_phi_i = double(rot_phi_i);
        
        [rot35, phi35, c35] = SimpJanbu3D(mask_red, csize, Slope, Aspect, asp,...
            0, 35, W0, u_i, gi, 'c', kx, ky, Ex, Ey);
        F(idx).phi35 = double(phi35);
        F(idx).c35 = double(c35);
        F(idx).rot35 = double(rot35);
        
        
        % ADD OTHER ATTRIBUTES (E, kx, etc) HERE

    end
    fprintf(['Slide ',num2str(idx),' of ',num2str(length(F)),'\n'])
    S = []; G = []; Slope = []; Aspect = [];
end

shapewrite(F,ba_shp)

toc
%%---------------%-------------%--------------%----------------%-----------
function mask = create_shp_mask(shapefile,feat_num,geotiffinfo)
    %% Create binary mask from input polygons
	% Get x-y locations of pixels
	[x,y] = pixcenters(geotiffinfo);
	
	% Convert x-y arrays to grid
	[X,Y] = meshgrid(x,y);
	
	% Select single polygon and remove training NaN
	rx = shapefile(feat_num).X(1:end-1);
	ry = shapefile(feat_num).Y(1:end-1);
	
	mask = inpolygon(X,Y,rx,ry);
end

function [Slope,Aspect,dx,dy] = gradient_king(Elevation,csize)
% dy   negative: south  positive: north  values are rise/run
% dx   negative: west   positive: east   values are rise/run
% Aspect starts north and rotates clockwise
% Slope is in degrees

    % compute size of sub-matrix
    [m,n] = size(Elevation);
    Slope = zeros(m,n);
    Aspect = Slope;
    dx = Aspect;
    dy = dx;

    for j = 2:m-1
        for k = 2:n-1

            % Perform gradeint computations as in ArcGIS
            dz_dx = (((Elevation(j-1,k+1))+2*(Elevation(j,k+1))+(Elevation(j+1,k+1)))-((Elevation(j-1,k-1))...
                +2*(Elevation(j,k-1))+(Elevation(j+1,k-1))))/(8*csize);
            dz_dy = (((Elevation(j+1,k-1))+2*(Elevation(j+1,k))+(Elevation(j+1,k+1)))-((Elevation(j-1,k-1))...
                +2*(Elevation(j-1,k))+(Elevation(j-1,k+1))))/(8*csize);

            % Compute Slope
            rise_run = sqrt(dz_dx^2+dz_dy^2);
            slope_degrees = atan(rise_run)*57.29578;
            Slope(j,k) = slope_degrees;
            
            % Compute Aspect
            aspect = 57.29578*atan2(dz_dy,-dz_dx);
            cell = aspect; 
            if aspect < 0
                cell = 90-aspect;
            elseif aspect >90
                cell = 360-aspect+90;
            else
                cell = 90-aspect;
            end
            Aspect(j,k) = cell;
            
            % Package dx and dy
            dy(j,k) = dz_dy;
            dx(j,k) = -dz_dx;

        end
    end
end
